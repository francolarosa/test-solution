import { Given, When, Then } from '@wdio/cucumber-framework';
import SearcherPage from '../page-objects/searcher.js';

const ebay_site = 'https://www.ebay.com/';

Given(/^the user goes to ebay web site$/, async () => {
    await SearcherPage.openWebSite(ebay_site);
});

When(/^the user search (\w+)$/, async (word) => {
    await SearcherPage.searchWord(word);
});

Then(/^the user sees the number of results$/, async () => {
    await SearcherPage.displayResults();
});
