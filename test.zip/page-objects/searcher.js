class SearcherPage {
    /**
    * Searcher input element
    * @readonly
    * @returns {Object}
    */
    get searcherInput() {
        return $('input#kw.gh-search__input');
    }

    /**
    * Searcher button element
    * @readonly
    * @returns {Object}
    */
    get searcherButton() {
        return $('button.gh-search__submitbtn');
    }

    /**
    * Searcher results element
    * @readonly
    * @returns {Object}
    */
    get searcherResults() {
        return $('h1.result-count__count-heading');
    }

    /**
    * Opens a web page
    * @public
    * @param {String} urlPath - the url web path to open
    */
    async openWebSite(urlPath = '') {
        await browser.url(urlPath);
    }

    /**
    * Search the word
    * @public
    * @param {String} word - the word to search
    */
    async searchWord(word = '') {
        await this.searcherInput.setValue(word);
        await this.searcherButton.click();
    }

    /**
    * Display the results of search
    * @public
    */
    async displayResults() {
        const results = await this.searcherResults.getText();
        console.log('\n\n', results, '\n\n');
    }
}

export default new SearcherPage();
